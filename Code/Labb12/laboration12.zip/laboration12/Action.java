package laboration12;

public interface Action<T> {
    public void action( T value );
}
